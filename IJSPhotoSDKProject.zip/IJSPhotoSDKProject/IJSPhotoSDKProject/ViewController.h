//
//  ViewController.h
//  IJSPhotoSDKProject
//
//  Created by shan on 2017/6/30.
//  Copyright © 2017年 shanshen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
