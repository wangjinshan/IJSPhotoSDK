//
//  IJSVideoTestController.h
//  IJSPhotoSDKProject
//
//  Created by shange on 2017/8/30.
//  Copyright © 2017年 shanshen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface IJSVideoTestController : UIViewController

@property (nonatomic, strong) AVAsset *avasset; // 资源

@end
