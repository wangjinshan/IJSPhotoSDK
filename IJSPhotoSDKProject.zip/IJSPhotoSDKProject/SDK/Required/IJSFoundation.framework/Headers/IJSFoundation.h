//
//  IJSFoundtion.h
//  IJSOCproject
//
//  Created by shange on 2017/4/24.
//  Copyright © 2017年 jinshan. All rights reserved.
//

#ifndef IJSFoundation_h
#define IJSFoundation_h

#import "IJSFViewController.h"
#import "IJSFColor.h"
#import "IJSFDevice.h"
#import "IJSFImageGet.h"
#import "IJSFFilesManager.h"

#import "IJSFJson.h"
#import "IJSFRegexCategory.h"
#import "IJSFURL.h"
#import "IJSFImage.h"
#import "IJSFPhotos.h"

#import "IJSFNSArray.h"

#endif /* IJSFoundtion_h */
