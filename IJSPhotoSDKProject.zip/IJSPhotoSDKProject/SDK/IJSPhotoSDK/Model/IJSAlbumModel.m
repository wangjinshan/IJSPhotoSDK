//
//  IJSAlbumModel.m
//  JSPhotoSDK
//
//  Created by shan on 2017/5/29.
//  Copyright © 2017年 shan. All rights reserved.
//

#import "IJSAlbumModel.h"

@implementation IJSAlbumModel

@end
