//
//  IJSPreviewGifView.h
//  JSPhotoSDK
//
//  Created by shan on 2017/6/15.
//  Copyright © 2017年 shan. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 * 展示gif类
 */
@class IJSAssetModel;

@interface IJSPreviewGifView : UIView

/* 数据模型 */
@property (nonatomic, weak) IJSAssetModel *assetModel;

@end
