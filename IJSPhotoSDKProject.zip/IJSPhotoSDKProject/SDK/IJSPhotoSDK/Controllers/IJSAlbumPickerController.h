//
//  IJSAlbumPickerController.h
//  JSPhotoSDK
//
//  Created by shan on 2017/5/29.
//  Copyright © 2017年 shan. All rights reserved.
//

#import <UIKit/UIKit.h>
/*
 *  相册列表控制器
 */

@interface IJSAlbumPickerController : UIViewController
/* 列数 */
@property (nonatomic, assign) NSInteger columnNumber;

@end
