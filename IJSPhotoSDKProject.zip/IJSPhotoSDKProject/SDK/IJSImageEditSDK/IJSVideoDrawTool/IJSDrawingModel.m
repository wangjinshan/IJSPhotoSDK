//
//  IJSDrawingModel.m
//  IJSUExtension
//
//  Created by shan on 2017/8/3.
//  Copyright © 2017年 shanshen. All rights reserved.
//

#import "IJSDrawingModel.h"

@implementation IJSDrawingModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
}

@end
