//
//  IJSMapViewThumbCell.h
//  IJSMapView
//
//  Created by shange on 2017/9/10.
//  Copyright © 2017年 shange. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IJSMapViewModel.h"

@interface IJSMapViewThumbCell : UICollectionViewCell

@property (nonatomic, weak) IJSMapViewModel *imageModel; // 数据

@end
