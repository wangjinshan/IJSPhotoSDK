//
//  IJSMapViewModel.m
//  IJSMapView
//
//  Created by shange on 2017/9/10.
//  Copyright © 2017年 shange. All rights reserved.
//

#import "IJSMapViewModel.h"

@implementation IJSMapViewModel

- (instancetype)initWithImageDataModel:(NSMutableArray *)imageArr
{
    self.imageDataArr = imageArr;
    return self;
}

@end
