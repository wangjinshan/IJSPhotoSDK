//
//  UITextField+IJSUTextField.h
//  IJSE
//
//  Created by shan on 2017/6/30.
//  Copyright © 2017年 shanshen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (IJSUTextField)
/*自定义的属性 */
@property (nonatomic, strong) UIColor *js_placeholderColor;

@end
