//
//  NSObject+IJSUKeyValue.m
//  IJSE
//
//  Created by shan on 2017/6/30.
//  Copyright © 2017年 shanshen. All rights reserved.
//

#import "NSObject+IJSUKeyValue.h"

@implementation NSObject (IJSUKeyValue)

+ (instancetype)objectWithKeyValues:(id)keyValues
{
    return nil;
}

@end
